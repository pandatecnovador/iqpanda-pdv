import { useCategories, useCreateCategory } from "@/hooks/use-products";
import { Plus, Tags } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertCategorySchema } from "@shared/schema";
import { Form, FormField, FormItem, FormLabel, FormControl } from "@/components/ui/form";
import { z } from "zod";

export default function Categories() {
  const { data: categories, isLoading } = useCategories();
  const [isOpen, setIsOpen] = useState(false);
  
  return (
    <div className="p-8 max-w-[1200px] mx-auto space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold font-display text-foreground">Categorías</h1>
          <p className="text-muted-foreground mt-1">Organiza tus productos.</p>
        </div>
        <Button onClick={() => setIsOpen(true)} className="bg-primary text-white">
          <Plus className="w-5 h-5 mr-2" /> Añadir Categoría
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {isLoading ? <p>Cargando...</p> : categories?.map((category) => (
          <div key={category.id} className="bg-card border border-border p-6 rounded-xl shadow-sm hover:shadow-md transition-all">
            <div className="flex items-start justify-between mb-4">
              <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center text-primary">
                <Tags className="w-6 h-6" />
              </div>
            </div>
            <h3 className="text-xl font-bold font-display">{category.name}</h3>
            <p className="text-sm text-muted-foreground mt-1">{category.description || "Sin descripción"}</p>
            <div className="mt-4 pt-4 border-t border-border flex justify-between items-center">
              <span className="text-xs bg-muted text-muted-foreground px-2 py-1 rounded-md font-mono">{category.slug}</span>
            </div>
          </div>
        ))}
      </div>

      <CreateCategoryDialog open={isOpen} onOpenChange={setIsOpen} />
    </div>
  );
}

function CreateCategoryDialog({ open, onOpenChange }: { open: boolean, onOpenChange: (open: boolean) => void }) {
  const { mutate: createCategory } = useCreateCategory();
  const { toast } = useToast();
  const form = useForm<z.infer<typeof insertCategorySchema>>({
    resolver: zodResolver(insertCategorySchema),
    defaultValues: { name: "", slug: "", description: "" }
  });

  const onSubmit = (data: any) => {
    createCategory(data, {
      onSuccess: () => {
        toast({ title: "Categoría creada" });
        onOpenChange(false);
        form.reset();
      }
    });
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader><DialogTitle>Añadir Categoría</DialogTitle></DialogHeader>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="name"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Nombre</FormLabel>
                  <FormControl><Input {...field} /></FormControl>
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="slug"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Slug</FormLabel>
                  <FormControl><Input {...field} placeholder="ej. electronica" /></FormControl>
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="description"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Descripción</FormLabel>
                  <FormControl><Input {...field} /></FormControl>
                </FormItem>
              )}
            />
            <Button type="submit" className="w-full bg-primary text-white">Crear</Button>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
