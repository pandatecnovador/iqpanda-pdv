import { useSuppliers, useCreateSupplier } from "@/hooks/use-products";
import { Plus, Users, Phone, Mail, Building } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertSupplierSchema } from "@shared/schema";
import { Form, FormField, FormItem, FormLabel, FormControl } from "@/components/ui/form";
import { z } from "zod";

export default function Suppliers() {
  const { data: suppliers, isLoading } = useSuppliers();
  const [isOpen, setIsOpen] = useState(false);
  
  return (
    <div className="p-8 max-w-[1200px] mx-auto space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold font-display text-foreground">Proveedores</h1>
          <p className="text-muted-foreground mt-1">Gestiona tus relaciones con proveedores.</p>
        </div>
        <Button onClick={() => setIsOpen(true)} className="bg-primary text-white">
          <Plus className="w-5 h-5 mr-2" /> Añadir Proveedor
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {isLoading ? <p>Cargando...</p> : suppliers?.map((supplier) => (
          <div key={supplier.id} className="bg-card border border-border p-6 rounded-xl shadow-sm hover:shadow-md transition-all">
            <div className="flex items-center gap-4 mb-4">
              <div className="w-12 h-12 rounded-full bg-secondary flex items-center justify-center text-foreground">
                <Building className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-xl font-bold font-display">{supplier.name}</h3>
                <p className="text-sm text-muted-foreground">{supplier.contactPerson}</p>
              </div>
            </div>
            <div className="space-y-2 mt-4 text-sm">
              <div className="flex items-center gap-2 text-muted-foreground">
                <Mail className="w-4 h-4" />
                <span>{supplier.email || "Sin correo"}</span>
              </div>
              <div className="flex items-center gap-2 text-muted-foreground">
                <Phone className="w-4 h-4" />
                <span>{supplier.phone || "Sin teléfono"}</span>
              </div>
            </div>
            <div className="mt-4 pt-4 border-t border-border">
              <span className="text-xs font-mono text-muted-foreground">RFC: {supplier.rfc || "N/A"}</span>
            </div>
          </div>
        ))}
      </div>

      <CreateSupplierDialog open={isOpen} onOpenChange={setIsOpen} />
    </div>
  );
}

function CreateSupplierDialog({ open, onOpenChange }: { open: boolean, onOpenChange: (open: boolean) => void }) {
  const { mutate: createSupplier } = useCreateSupplier();
  const { toast } = useToast();
  const form = useForm<z.infer<typeof insertSupplierSchema>>({
    resolver: zodResolver(insertSupplierSchema),
    defaultValues: { name: "", rfc: "", email: "", phone: "", contactPerson: "" }
  });

  const onSubmit = (data: any) => {
    createSupplier(data, {
      onSuccess: () => {
        toast({ title: "Proveedor creado" });
        onOpenChange(false);
        form.reset();
      }
    });
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader><DialogTitle>Añadir Proveedor</DialogTitle></DialogHeader>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="name"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Nombre</FormLabel>
                  <FormControl><Input {...field} /></FormControl>
                </FormItem>
              )}
            />
            <div className="grid grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="rfc"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>RFC</FormLabel>
                    <FormControl><Input {...field} /></FormControl>
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="contactPerson"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Persona de Contacto</FormLabel>
                    <FormControl><Input {...field} /></FormControl>
                  </FormItem>
                )}
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="email"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Correo</FormLabel>
                    <FormControl><Input {...field} type="email" /></FormControl>
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="phone"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Teléfono</FormLabel>
                    <FormControl><Input {...field} /></FormControl>
                  </FormItem>
                )}
              />
            </div>
            <Button type="submit" className="w-full bg-primary text-white">Crear</Button>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
