import { usePredictDemand } from "@/hooks/use-dashboard";
import { Sparkles, TrendingUp } from "lucide-react";
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from "recharts";
import { Button } from "@/components/ui/button";

export default function Insights() {
  const { data, isLoading } = usePredictDemand(7);

  return (
    <div className="p-8 max-w-[1600px] mx-auto space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <Sparkles className="w-5 h-5 text-primary" />
            <h1 className="text-3xl font-bold font-display text-foreground">Análisis IA</h1>
          </div>
          <p className="text-muted-foreground">Predicción de demanda para los próximos 7 días.</p>
        </div>
        <Button disabled className="bg-primary/10 text-primary hover:bg-primary/20">
          Generar Nuevo Informe
        </Button>
      </div>

      <div className="bg-card border border-border rounded-2xl p-6 shadow-sm">
        <h3 className="text-lg font-bold font-display mb-6">Volumen de Ventas Previsto</h3>
        
        {isLoading ? (
          <div className="h-[400px] flex items-center justify-center text-muted-foreground">Generando predicciones de IA...</div>
        ) : (
          <div className="h-[400px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={data?.predictions}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e5e7eb" />
                <XAxis 
                  dataKey="date" 
                  axisLine={false} 
                  tickLine={false} 
                  tick={{ fill: '#64748b', fontSize: 12 }} 
                  dy={10}
                />
                <YAxis 
                  axisLine={false} 
                  tickLine={false} 
                  tick={{ fill: '#64748b', fontSize: 12 }} 
                />
                <Tooltip 
                  contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }}
                />
                <Line 
                  type="monotone" 
                  dataKey="predictedSales" 
                  stroke="hsl(var(--primary))" 
                  strokeWidth={3}
                  dot={{ r: 4, strokeWidth: 2, fill: 'white' }}
                  activeDot={{ r: 8 }}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        )}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {data?.predictions.map((pred: any, i: number) => (
          <div key={i} className="bg-card border border-border p-5 rounded-xl">
            <div className="flex justify-between items-start mb-2">
              <span className="font-semibold text-foreground">{pred.date}</span>
              <span className="text-primary font-bold">{pred.predictedSales} ventas</span>
            </div>
            <p className="text-sm text-muted-foreground leading-relaxed">
              {pred.reasoning}
            </p>
          </div>
        ))}
      </div>
    </div>
  );
}
