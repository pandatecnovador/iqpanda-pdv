import { useState } from "react";
import { useProducts } from "@/hooks/use-products";
import { useCreateSale } from "@/hooks/use-sales";
import { Search, Plus, Minus, Trash2, CreditCard, Banknote, ShoppingBag } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";
import { motion, AnimatePresence } from "framer-motion";

interface CartItem {
  id: number;
  name: string;
  price: number;
  quantity: number;
}

export default function POS() {
  const [search, setSearch] = useState("");
  const { data: products, isLoading } = useProducts(search);
  const [cart, setCart] = useState<CartItem[]>([]);
  const { mutate: createSale, isPending } = useCreateSale();
  const { toast } = useToast();

  const addToCart = (product: any) => {
    setCart((prev) => {
      const existing = prev.find((item) => item.id === product.id);
      if (existing) {
        return prev.map((item) =>
          item.id === product.id ? { ...item, quantity: item.quantity + 1 } : item
        );
      }
      return [...prev, { id: product.id, name: product.name, price: Number(product.salePrice), quantity: 1 }];
    });
  };

  const removeFromCart = (id: number) => {
    setCart((prev) => prev.filter((item) => item.id !== id));
  };

  const updateQuantity = (id: number, delta: number) => {
    setCart((prev) => {
      return prev.map((item) => {
        if (item.id === id) {
          const newQty = Math.max(1, item.quantity + delta);
          return { ...item, quantity: newQty };
        }
        return item;
      });
    });
  };

  const total = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);

  const handleCheckout = (method: string) => {
    if (cart.length === 0) return;

    createSale(
      {
        paymentMethod: method,
        items: cart.map((item) => ({ productId: item.id, quantity: item.quantity })),
      },
      {
        onSuccess: () => {
          toast({ title: "¡Venta completada!", description: `Recibo generado por $${total.toFixed(2)}` });
          setCart([]);
        },
        onError: (err) => {
          toast({ title: "Error", description: err.message, variant: "destructive" });
        },
      }
    );
  };

  return (
    <div className="flex h-screen bg-background overflow-hidden">
      {/* Product Grid - Left Side */}
      <div className="flex-1 flex flex-col p-6 pr-2">
        <div className="mb-6 flex gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground w-5 h-5" />
            <Input
              placeholder="Buscar productos por nombre o SKU..."
              className="pl-10 h-12 text-lg rounded-xl bg-card border-border/60 shadow-sm"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>
        </div>

        <div className="flex-1 overflow-y-auto pr-2">
          {isLoading ? (
            <div className="flex items-center justify-center h-full text-muted-foreground">Cargando productos...</div>
          ) : (
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 pb-20">
              {products?.map((product) => (
                <motion.div
                  key={product.id}
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  whileHover={{ y: -4, shadow: "0 10px 30px -10px rgba(0,0,0,0.1)" }}
                  className="bg-card border border-border rounded-xl p-4 cursor-pointer flex flex-col h-full shadow-sm transition-all"
                  onClick={() => addToCart(product)}
                >
                  <div className="aspect-square rounded-lg bg-muted mb-3 flex items-center justify-center relative overflow-hidden">
                    {product.imageUrl ? (
                       <img src={product.imageUrl} alt={product.name} className="w-full h-full object-cover" />
                    ) : (
                      <ShoppingBag className="w-10 h-10 text-muted-foreground/30" />
                    )}
                    <div className="absolute top-2 right-2 bg-black/50 backdrop-blur-md text-white text-xs font-bold px-2 py-1 rounded-full">
                      Stock: {product.stock}
                    </div>
                  </div>
                  <h3 className="font-bold text-foreground line-clamp-2 mb-1">{product.name}</h3>
                  <p className="text-sm text-muted-foreground mb-auto">{product.sku}</p>
                  <div className="mt-3 text-lg font-bold text-primary">
                    ${Number(product.salePrice).toFixed(2)}
                  </div>
                </motion.div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Cart - Right Side */}
      <div className="w-[400px] bg-card border-l border-border flex flex-col shadow-2xl z-20">
        <div className="p-6 border-b border-border bg-muted/20">
          <h2 className="text-xl font-bold font-display">Pedido Actual</h2>
          <p className="text-sm text-muted-foreground">{cart.length} artículos en el carrito</p>
        </div>

        <div className="flex-1 overflow-y-auto p-4 space-y-3">
          <AnimatePresence>
            {cart.map((item) => (
              <motion.div
                key={item.id}
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="flex items-center justify-between p-3 bg-background border border-border rounded-xl shadow-sm"
              >
                <div className="flex-1">
                  <h4 className="font-semibold text-sm line-clamp-1">{item.name}</h4>
                  <p className="text-primary font-bold text-sm">${(item.price * item.quantity).toFixed(2)}</p>
                </div>
                <div className="flex items-center gap-3">
                  <button
                    onClick={() => updateQuantity(item.id, -1)}
                    className="w-8 h-8 rounded-full bg-muted flex items-center justify-center hover:bg-muted-foreground/20 transition-colors"
                  >
                    <Minus className="w-4 h-4" />
                  </button>
                  <span className="font-bold w-4 text-center">{item.quantity}</span>
                  <button
                    onClick={() => updateQuantity(item.id, 1)}
                    className="w-8 h-8 rounded-full bg-primary/10 text-primary flex items-center justify-center hover:bg-primary/20 transition-colors"
                  >
                    <Plus className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => removeFromCart(item.id)}
                    className="ml-2 text-muted-foreground hover:text-destructive transition-colors"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
          {cart.length === 0 && (
            <div className="flex flex-col items-center justify-center h-40 text-muted-foreground opacity-50">
              <ShoppingBag className="w-12 h-12 mb-2" />
              <p>El carrito está vacío</p>
            </div>
          )}
        </div>

        <div className="p-6 border-t border-border bg-muted/20 space-y-4">
          <div className="flex items-center justify-between text-lg font-bold">
            <span>Total</span>
            <span className="text-2xl text-primary">${total.toFixed(2)}</span>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <Button
              size="lg"
              variant="outline"
              className="h-14 text-base font-bold gap-2 border-primary/20 hover:bg-primary/5 hover:text-primary"
              onClick={() => handleCheckout("Efectivo")}
              disabled={isPending || cart.length === 0}
            >
              <Banknote className="w-5 h-5" />
              Efectivo
            </Button>
            <Button
              size="lg"
              className="h-14 text-base font-bold gap-2 bg-primary hover:bg-primary/90 shadow-lg shadow-primary/25"
              onClick={() => handleCheckout("Tarjeta")}
              disabled={isPending || cart.length === 0}
            >
              <CreditCard className="w-5 h-5" />
              Tarjeta
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
