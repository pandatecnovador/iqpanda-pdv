import { useSales } from "@/hooks/use-sales";
import { format } from "date-fns";
import { DollarSign, CreditCard, Calendar } from "lucide-react";

export default function Sales() {
  const { data: sales, isLoading } = useSales();

  return (
    <div className="p-8 max-w-[1600px] mx-auto space-y-8">
      <div>
        <h1 className="text-3xl font-bold font-display text-foreground">Historial de Ventas</h1>
        <p className="text-muted-foreground mt-1">Ver transacciones recientes.</p>
      </div>

      <div className="bg-card border border-border rounded-2xl shadow-sm overflow-hidden">
        {isLoading ? (
          <div className="p-8 text-center text-muted-foreground">Cargando ventas...</div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm text-left">
              <thead className="bg-muted/50 text-muted-foreground font-medium uppercase text-xs">
                <tr>
                  <th className="px-6 py-4">Nº Recibo</th>
                  <th className="px-6 py-4">Fecha</th>
                  <th className="px-6 py-4">Método de Pago</th>
                  <th className="px-6 py-4 text-right">Total</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {sales?.map((sale) => (
                  <tr key={sale.id} className="hover:bg-muted/30 transition-colors">
                    <td className="px-6 py-4 font-mono font-medium">{sale.receiptNumber}</td>
                    <td className="px-6 py-4 text-muted-foreground flex items-center gap-2">
                      <Calendar className="w-4 h-4" />
                      {sale.createdAt ? format(new Date(sale.createdAt), "d MMM, yyyy h:mm a") : "-"}
                    </td>
                    <td className="px-6 py-4">
                      <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md text-xs font-medium bg-secondary text-secondary-foreground">
                        <CreditCard className="w-3 h-3" />
                        {sale.paymentMethod}
                      </span>
                    </td>
                    <td className="px-6 py-4 text-right font-bold text-foreground">
                      ${Number(sale.total).toFixed(2)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
