import { useDashboardStats } from "@/hooks/use-dashboard";
import { StatCard } from "@/components/StatCard";
import { DollarSign, ShoppingBag, AlertTriangle, TrendingUp } from "lucide-react";
import { motion } from "framer-motion";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from "recharts";

export default function Dashboard() {
  const { data: stats, isLoading } = useDashboardStats();

  const container = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  const item = {
    hidden: { y: 20, opacity: 0 },
    show: { y: 0, opacity: 1 }
  };

  if (isLoading) {
    return <div className="p-8 flex items-center justify-center h-full">Cargando panel...</div>;
  }

  // Mock data for the chart since we don't have historical endpoint yet
  const chartData = [
    { name: "Lun", sales: 4000 },
    { name: "Mar", sales: 3000 },
    { name: "Mié", sales: 2000 },
    { name: "Jue", sales: 2780 },
    { name: "Vie", sales: 1890 },
    { name: "Sáb", sales: 2390 },
    { name: "Dom", sales: 3490 },
  ];

  return (
    <div className="p-8 space-y-8 max-w-[1600px] mx-auto">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold font-display text-foreground">Panel de Control</h1>
          <p className="text-muted-foreground mt-1">Resumen del rendimiento de tu tienda hoy.</p>
        </div>
        <div className="px-4 py-2 bg-white border border-border rounded-lg text-sm font-medium text-foreground shadow-sm">
          {new Date().toLocaleDateString("es-ES", { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
        </div>
      </div>

      <motion.div 
        variants={container}
        initial="hidden"
        animate="show"
        className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6"
      >
        <motion.div variants={item}>
          <StatCard
            title="Ventas Totales Hoy"
            value={`$${stats?.totalSalesToday.toFixed(2) || "0.00"}`}
            icon={<DollarSign className="w-6 h-6" />}
            trend={{ value: 12, isPositive: true }}
          />
        </motion.div>
        <motion.div variants={item}>
          <StatCard
            title="Pedidos Hoy"
            value={stats?.totalOrdersToday || 0}
            icon={<ShoppingBag className="w-6 h-6" />}
          />
        </motion.div>
        <motion.div variants={item}>
          <StatCard
            title="Productos con Stock Bajo"
            value={stats?.lowStockCount || 0}
            icon={<AlertTriangle className="w-6 h-6" />}
            className="border-amber-200 bg-amber-50/50"
          />
        </motion.div>
        <motion.div variants={item}>
          <StatCard
            title="Valor Promedio de Pedido"
            value={`$${stats?.totalOrdersToday ? (stats.totalSalesToday / stats.totalOrdersToday).toFixed(2) : "0.00"}`}
            icon={<TrendingUp className="w-6 h-6" />}
          />
        </motion.div>
      </motion.div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="lg:col-span-2 bg-card rounded-2xl border border-border p-6 shadow-sm"
        >
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-lg font-bold font-display">Resumen de Ventas Semanales</h3>
          </div>
          <div className="h-[300px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e5e7eb" />
                <XAxis 
                  dataKey="name" 
                  axisLine={false} 
                  tickLine={false} 
                  tick={{ fill: '#64748b', fontSize: 12 }} 
                  dy={10}
                />
                <YAxis 
                  axisLine={false} 
                  tickLine={false} 
                  tick={{ fill: '#64748b', fontSize: 12 }} 
                  tickFormatter={(value) => `$${value}`}
                />
                <Tooltip 
                  cursor={{ fill: '#f1f5f9' }}
                  contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }}
                />
                <Bar 
                  dataKey="sales" 
                  fill="hsl(var(--primary))" 
                  radius={[6, 6, 0, 0]} 
                  barSize={32}
                />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </motion.div>

        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
          className="bg-card rounded-2xl border border-border p-6 shadow-sm"
        >
          <h3 className="text-lg font-bold font-display mb-6">Productos Más Vendidos</h3>
          <div className="space-y-4">
            {stats?.topSellingProducts.map((product, i) => (
              <div key={i} className="flex items-center justify-between p-3 rounded-xl hover:bg-muted/50 transition-colors">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center text-primary text-xs font-bold">
                    #{i + 1}
                  </div>
                  <span className="font-medium text-sm">{product.name}</span>
                </div>
                <span className="text-sm font-semibold text-muted-foreground">{product.quantity} vendidos</span>
              </div>
            ))}
            {(!stats?.topSellingProducts || stats.topSellingProducts.length === 0) && (
              <div className="text-center text-muted-foreground py-8 text-sm">Aún no hay ventas hoy</div>
            )}
          </div>
        </motion.div>
      </div>
    </div>
  );
}
