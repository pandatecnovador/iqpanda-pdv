import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import Dashboard from "@/pages/Dashboard";
import POS from "@/pages/POS";
import Products from "@/pages/Products";
import Categories from "@/pages/Categories";
import Suppliers from "@/pages/Suppliers";
import Sales from "@/pages/Sales";
import Insights from "@/pages/Insights";
import { Sidebar } from "@/components/Sidebar";

function Router() {
  return (
    <div className="flex min-h-screen bg-background text-foreground">
      <Sidebar />
      <main className="flex-1 ml-64 bg-background">
        <Switch>
          <Route path="/" component={Dashboard} />
          <Route path="/pos" component={POS} />
          <Route path="/products" component={Products} />
          <Route path="/categories" component={Categories} />
          <Route path="/suppliers" component={Suppliers} />
          <Route path="/sales" component={Sales} />
          <Route path="/insights" component={Insights} />
          <Route component={NotFound} />
        </Switch>
      </main>
    </div>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Router />
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
