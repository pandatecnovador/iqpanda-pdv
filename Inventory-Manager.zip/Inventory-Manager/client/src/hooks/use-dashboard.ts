import { useQuery } from "@tanstack/react-query";
import { api } from "@shared/routes";

export function useDashboardStats() {
  return useQuery({
    queryKey: [api.dashboard.stats.path],
    queryFn: async () => {
      const res = await fetch(api.dashboard.stats.path, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch dashboard stats");
      return api.dashboard.stats.responses[200].parse(await res.json());
    },
    refetchInterval: 30000, // Refresh every 30s
  });
}

export function usePredictDemand(days: number = 7) {
  return useQuery({
    queryKey: [api.ai.predictDemand.path, days],
    queryFn: async () => {
      const res = await fetch(api.ai.predictDemand.path, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ days }),
        credentials: "include",
      });
      if (!res.ok) throw new Error("Failed to fetch predictions");
      return api.ai.predictDemand.responses[200].parse(await res.json());
    },
    staleTime: 1000 * 60 * 60, // 1 hour stale time for AI predictions
  });
}
