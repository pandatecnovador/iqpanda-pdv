## Packages
recharts | Dashboard analytics and sales trends charts
framer-motion | Smooth page transitions and micro-interactions
date-fns | Date formatting for sales history and charts
@tanstack/react-table | Powerful data tables for inventory management

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  display: ["var(--font-display)"],
  body: ["var(--font-body)"],
}
POS interface requires specific grid layout for products vs cart
AI endpoint /api/ai/predict-demand expects { days: number }
