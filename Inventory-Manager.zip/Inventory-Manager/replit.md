# NexusPOS - Point of Sale System

## Overview

NexusPOS is a full-stack Point of Sale (POS) and inventory management system built for retail businesses. The UI is in Spanish, targeting Spanish-speaking markets. It provides a dashboard with analytics, a POS terminal for processing sales, product/category/supplier management, sales history, and an AI-powered demand prediction feature. The app follows a monorepo structure with a React frontend, Express backend, and PostgreSQL database.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Monorepo Structure
The project uses a three-directory monorepo pattern:
- **`client/`** — React SPA frontend
- **`server/`** — Express API backend
- **`shared/`** — Code shared between client and server (schema definitions, route contracts)

### Frontend Architecture
- **Framework:** React with TypeScript (no SSR, `rsc: false`)
- **Routing:** Wouter (lightweight client-side router)
- **State/Data Fetching:** TanStack React Query for server state management
- **UI Components:** shadcn/ui (new-york style) built on Radix UI primitives
- **Styling:** Tailwind CSS with CSS variables for theming (indigo-violet color scheme)
- **Charts:** Recharts for dashboard analytics and sales charts
- **Animations:** Framer Motion for page transitions and micro-interactions
- **Forms:** React Hook Form with Zod resolvers for validation
- **Data Tables:** TanStack React Table for inventory management
- **Build Tool:** Vite with HMR support via custom dev server integration
- **Path Aliases:** `@/` maps to `client/src/`, `@shared/` maps to `shared/`

### Backend Architecture
- **Framework:** Express.js running on Node.js with TypeScript (via tsx)
- **HTTP Server:** Node's `createServer` wrapping Express (supports WebSocket upgrades if needed)
- **API Pattern:** RESTful JSON API under `/api/` prefix
- **Route Contracts:** Shared route definitions in `shared/routes.ts` with Zod schemas for input validation and response typing — both client and server reference the same contract
- **Dev Mode:** Vite dev server is mounted as Express middleware for HMR
- **Production:** Client is built with Vite, server is bundled with esbuild into `dist/index.cjs`

### Database & ORM
- **Database:** PostgreSQL (required, via `DATABASE_URL` environment variable)
- **ORM:** Drizzle ORM with `drizzle-zod` for automatic Zod schema generation from table definitions
- **Schema Location:** `shared/schema.ts` — contains all table definitions, relations, insert schemas, and TypeScript types
- **Migrations:** Drizzle Kit with `drizzle-kit push` command for schema synchronization
- **Connection:** `pg` Pool via `server/db.ts`
- **Session Store:** `connect-pg-simple` (PostgreSQL-backed sessions)

### Key Database Tables
- **users** — Authentication with roles (administrador, cajero, supervisor)
- **products** — Full product catalog with SKU, barcode, pricing (cost/sale/wholesale), stock levels
- **categories** — Product categorization with slug-based identification
- **suppliers** — Supplier management with RFC (Mexican tax ID), contact info
- **sales** — Sales transactions with receipt numbers and payment methods
- **saleItems** — Line items for each sale
- **inventoryMovements** — Stock movement tracking

### Storage Pattern
- `server/storage.ts` defines an `IStorage` interface and `DatabaseStorage` implementation
- This abstraction allows swapping storage backends if needed
- All database operations go through the storage layer

### API Endpoints
- `GET/POST /api/products` — List and create products
- `GET/PUT/DELETE /api/products/:id` — Single product CRUD
- `GET/POST /api/categories` — Category management
- `GET/POST /api/suppliers` — Supplier management
- `GET/POST /api/sales` — Sales listing and creation
- `GET /api/dashboard/stats` — Dashboard statistics
- `POST /api/ai/predict-demand` — AI demand prediction (expects `{ days: number }`)

### Build & Deployment
- **Dev:** `npm run dev` runs tsx with Vite middleware for HMR
- **Build:** `npm run build` runs a custom build script that builds client with Vite and server with esbuild
- **Production:** `npm start` runs the compiled `dist/index.cjs`
- **DB Schema Push:** `npm run db:push` syncs schema to database

## External Dependencies

### Required Services
- **PostgreSQL Database** — Primary data store, connection via `DATABASE_URL` environment variable. Must be provisioned before the app can start.

### Key NPM Packages
- **drizzle-orm / drizzle-kit** — ORM and migration tooling for PostgreSQL
- **express** — HTTP server framework
- **@tanstack/react-query** — Client-side data fetching and caching
- **zod / drizzle-zod** — Schema validation shared between client and server
- **recharts** — Charting library for dashboard and insights
- **framer-motion** — Animation library
- **react-hook-form** — Form state management
- **wouter** — Client-side routing
- **date-fns** — Date formatting
- **connect-pg-simple** — PostgreSQL session store

### Potential AI Integration
The codebase references an AI demand prediction endpoint (`/api/ai/predict-demand`). The build script allowlists `@google/generative-ai` and `openai`, suggesting either Google Gemini or OpenAI may be used for AI features. The corresponding API keys would need to be configured as environment variables.

### Replit-Specific Plugins
- `@replit/vite-plugin-runtime-error-modal` — Runtime error overlay
- `@replit/vite-plugin-cartographer` — Dev tooling (dev only)
- `@replit/vite-plugin-dev-banner` — Dev banner (dev only)