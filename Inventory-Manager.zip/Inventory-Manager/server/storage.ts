import { db } from "./db";
import {
  users, products, categories, suppliers, sales, saleItems, inventoryMovements,
  type User, type InsertUser, type Product, type InsertProduct,
  type Category, type Sale, type SaleItem, type InsertSale, type InsertSaleItem,
  type DashboardStats,
  type Supplier, type InsertSupplier
} from "@shared/schema";
import { eq, desc, sql, and, gte, lte } from "drizzle-orm";

export interface IStorage {
  // Users
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Products
  getProducts(search?: string, categoryId?: number): Promise<Product[]>;
  getProduct(id: number): Promise<Product | undefined>;
  createProduct(product: InsertProduct): Promise<Product>;
  updateProduct(id: number, product: Partial<InsertProduct>): Promise<Product>;
  deleteProduct(id: number): Promise<void>;

  // Categories
  getCategories(): Promise<Category[]>;
  createCategory(category: { name: string; slug: string; description?: string }): Promise<Category>;

  // Suppliers
  getSuppliers(): Promise<Supplier[]>;
  createSupplier(supplier: InsertSupplier): Promise<Supplier>;

  // Sales
  createSale(sale: InsertSale, items: { productId: number; quantity: number }[]): Promise<Sale>;
  getSales(): Promise<Sale[]>;
  
  // Dashboard
  getDashboardStats(): Promise<DashboardStats>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async createUser(user: InsertUser): Promise<User> {
    const [newUser] = await db.insert(users).values(user).returning();
    return newUser;
  }

  async getProducts(search?: string, categoryId?: number): Promise<Product[]> {
    let query = db.select().from(products);
    
    // In a real app with more data, we'd use dynamic where clauses properly
    const allProducts = await query;
    
    return allProducts.filter(p => {
      const matchSearch = search ? p.name.toLowerCase().includes(search.toLowerCase()) || p.sku.includes(search) : true;
      const matchCategory = categoryId ? p.categoryId === categoryId : true;
      return matchSearch && matchCategory;
    });
  }

  async getProduct(id: number): Promise<Product | undefined> {
    const [product] = await db.select().from(products).where(eq(products.id, id));
    return product;
  }

  async createProduct(product: InsertProduct): Promise<Product> {
    const [newProduct] = await db.insert(products).values(product).returning();
    return newProduct;
  }

  async updateProduct(id: number, updates: Partial<InsertProduct>): Promise<Product> {
    const [updated] = await db.update(products).set(updates).where(eq(products.id, id)).returning();
    return updated;
  }

  async deleteProduct(id: number): Promise<void> {
    await db.delete(products).where(eq(products.id, id));
  }

  async getCategories(): Promise<Category[]> {
    return db.select().from(categories);
  }

  async createCategory(category: { name: string; slug: string; description?: string }): Promise<Category> {
    const [newCategory] = await db.insert(categories).values(category).returning();
    return newCategory;
  }

  async getSuppliers(): Promise<Supplier[]> {
    return db.select().from(suppliers);
  }

  async createSupplier(supplier: InsertSupplier): Promise<Supplier> {
    const [newSupplier] = await db.insert(suppliers).values(supplier).returning();
    return newSupplier;
  }

  async createSale(saleData: InsertSale, itemsData: { productId: number; quantity: number }[]): Promise<Sale> {
    // Start transaction
    return await db.transaction(async (tx) => {
      // 1. Create Sale
      const [sale] = await tx.insert(sales).values({
        ...saleData,
        receiptNumber: `REC-${Date.now()}` // Simple receipt number generation
      }).returning();

      // 2. Create Sale Items and Update Stock
      for (const item of itemsData) {
        const [product] = await tx.select().from(products).where(eq(products.id, item.productId));
        if (!product) throw new Error(`Product ${item.productId} not found`);

        const unitPrice = product.salePrice;
        const subtotal = (Number(unitPrice) * item.quantity).toString();

        await tx.insert(saleItems).values({
          saleId: sale.id,
          productId: item.productId,
          quantity: String(item.quantity),
          unitPrice: String(unitPrice),
          subtotal: subtotal
        });

        // Update Stock
        const currentStock = Number(product.stock);
        await tx.update(products)
          .set({ stock: String(currentStock - item.quantity) })
          .where(eq(products.id, item.productId));
        
        // Log movement
        await tx.insert(inventoryMovements).values({
          productId: item.productId,
          type: "VENTA",
          quantity: String(item.quantity),
          reason: `Venta #${sale.receiptNumber}`
        });
      }

      return sale;
    });
  }

  async getSales(): Promise<Sale[]> {
    return db.select().from(sales).orderBy(desc(sales.createdAt));
  }

  async getDashboardStats(): Promise<DashboardStats> {
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    const salesToday = await db.select().from(sales).where(gte(sales.createdAt, today));
    
    const totalSalesToday = salesToday.reduce((sum, sale) => sum + Number(sale.total), 0);
    const totalOrdersToday = salesToday.length;

    const productsList = await db.select().from(products);
    const lowStockCount = productsList.filter(p => Number(p.stock) <= Number(p.minStock || 10)).length;

    // Simple top selling (mock logic for now, or aggregations)
    const topSellingProducts = [
      { name: "Producto A", quantity: 15 },
      { name: "Producto B", quantity: 12 },
      { name: "Producto C", quantity: 8 }
    ];

    return {
      totalSalesToday,
      totalOrdersToday,
      lowStockCount,
      topSellingProducts
    };
  }
}

export const storage = new DatabaseStorage();
