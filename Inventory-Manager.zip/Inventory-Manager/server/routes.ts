import type { Express } from "express";
import type { Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";
import { insertProductSchema, insertCategorySchema, insertSupplierSchema } from "@shared/schema";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {

  // Products
  app.get(api.products.list.path, async (req, res) => {
    const search = req.query.search as string | undefined;
    const categoryId = req.query.categoryId ? parseInt(req.query.categoryId as string) : undefined;
    const products = await storage.getProducts(search, categoryId);
    res.json(products);
  });

  app.get(api.products.get.path, async (req, res) => {
    const product = await storage.getProduct(Number(req.params.id));
    if (!product) {
      return res.status(404).json({ message: 'Product not found' });
    }
    res.json(product);
  });

  app.post(api.products.create.path, async (req, res) => {
    try {
      // Coerce numeric fields from string inputs if needed, though Zod handles JSON numbers fine.
      // But for robustness with numeric types in Drizzle (which are strings for numeric/decimal),
      // we might need some care. However, schema uses `numeric` which maps to string in JS.
      // Drizzle-zod schema expects strings for numeric fields by default.
      
      const input = insertProductSchema.parse(req.body);
      const product = await storage.createProduct(input);
      res.status(201).json(product);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({
          message: err.errors[0].message,
          field: err.errors[0].path.join('.'),
        });
      }
      throw err;
    }
  });

  app.put(api.products.update.path, async (req, res) => {
    try {
      const input = insertProductSchema.partial().parse(req.body);
      const product = await storage.updateProduct(Number(req.params.id), input);
      res.json(product);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({
          message: err.errors[0].message,
          field: err.errors[0].path.join('.'),
        });
      }
      return res.status(404).json({ message: 'Product not found' });
    }
  });

  app.delete(api.products.delete.path, async (req, res) => {
    await storage.deleteProduct(Number(req.params.id));
    res.status(204).end();
  });

  // Categories
  app.get(api.categories.list.path, async (req, res) => {
    const categories = await storage.getCategories();
    res.json(categories);
  });

  app.post(api.categories.create.path, async (req, res) => {
    try {
      const input = insertCategorySchema.parse(req.body);
      const category = await storage.createCategory(input);
      res.status(201).json(category);
    } catch (err) {
      res.status(400).json({ message: 'Invalid category data' });
    }
  });

  // Suppliers
  app.get(api.suppliers.list.path, async (req, res) => {
    const suppliers = await storage.getSuppliers();
    res.json(suppliers);
  });

  app.post(api.suppliers.create.path, async (req, res) => {
    try {
      const input = insertSupplierSchema.parse(req.body);
      const supplier = await storage.createSupplier(input);
      res.status(201).json(supplier);
    } catch (err) {
      res.status(400).json({ message: 'Invalid supplier data' });
    }
  });

  // Sales
  app.get(api.sales.list.path, async (req, res) => {
    const sales = await storage.getSales();
    res.json(sales);
  });

  app.post(api.sales.create.path, async (req, res) => {
    try {
      const { items, ...saleData } = req.body;
      
      // Calculate total
      let total = 0;
      const products = await storage.getProducts(); // Inefficient for large DB, but ok for MVP
      
      for (const item of items) {
        const product = products.find(p => p.id === item.productId);
        if (product) {
          total += Number(product.salePrice) * item.quantity;
        }
      }

      const sale = await storage.createSale({
        ...saleData,
        total: String(total),
        userId: 1, // Mock user ID for now
      }, items);
      
      res.status(201).json(sale);
    } catch (err) {
      console.error(err);
      res.status(400).json({ message: 'Error processing sale' });
    }
  });

  // Dashboard
  app.get(api.dashboard.stats.path, async (req, res) => {
    const stats = await storage.getDashboardStats();
    res.json(stats);
  });

  // AI Prediction Mock
  app.post(api.ai.predictDemand.path, async (req, res) => {
    const { days } = req.body;
    
    // Mock predictions
    const predictions = Array.from({ length: days }).map((_, i) => {
      const date = new Date();
      date.setDate(date.getDate() + i + 1);
      return {
        date: date.toISOString().split('T')[0],
        predictedSales: Math.floor(Math.random() * 50) + 10,
        reasoning: "Basado en tendencias históricas y estacionalidad."
      };
    });

    res.json({ predictions });
  });

  // Seed Data
  await seedDatabase();

  return httpServer;
}

async function seedDatabase() {
  const usersList = await storage.getUserByUsername("admin");
  if (!usersList) {
    await storage.createUser({
      username: "admin",
      password: "admin123", // In a real app, hash this!
      fullName: "Admin User",
      role: "administrador",
      isActive: true
    });
  }

  const categories = await storage.getCategories();
  if (categories.length === 0) {
    const cat1 = await storage.createCategory({ name: "Bebidas", slug: "bebidas", description: "Refrescos y jugos" });
    const cat2 = await storage.createCategory({ name: "Snacks", slug: "snacks", description: "Papas y botanas" });
    const cat3 = await storage.createCategory({ name: "Limpieza", slug: "limpieza", description: "Artículos de limpieza" });

    await storage.createSupplier({ name: "Coca Cola", rfc: "COCA123", email: "ventas@coca.com", phone: "555-1234" });
    
    await storage.createProduct({
      sku: "BEB-001",
      name: "Coca Cola 600ml",
      description: "Refresco de cola",
      categoryId: cat1.id,
      costPrice: "10.00",
      salePrice: "18.00",
      stock: "100",
      minStock: "20",
      unit: "pieza"
    });

    await storage.createProduct({
      sku: "SNK-001",
      name: "Sabritas Sal 45g",
      description: "Papas saladas",
      categoryId: cat2.id,
      costPrice: "12.00",
      salePrice: "16.00",
      stock: "50",
      minStock: "10",
      unit: "pieza"
    });
    
    console.log("Database seeded successfully!");
  }
}
